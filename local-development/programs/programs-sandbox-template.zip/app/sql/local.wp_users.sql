/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `wp_users` VALUES
(1,"local","$P$B.mI4R6ccoauXCAVLHraJ2H.p4hzgd0","local","dev-email@flywheel.local","","2017-06-09 17:19:10","",0,"local"),
(2,"programs","$P$B9KERKJvN0qKIjgvVtsAxP0xIFstfh0","programs","programs@programs.dev","","2017-06-09 17:50:02","",0,"Programs");
