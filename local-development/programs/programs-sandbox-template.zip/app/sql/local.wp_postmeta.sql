/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `wp_postmeta` VALUES
(1,2,"_wp_page_template","default"),
(6,6,"_wp_trash_meta_status","publish"),
(7,6,"_wp_trash_meta_time","1497030083"),
(8,7,"_edit_last","1"),
(9,7,"_wp_page_template","default"),
(10,7,"_edit_lock","1497029976:1"),
(11,9,"_wp_trash_meta_status","publish"),
(12,9,"_wp_trash_meta_time","1497030112"),
(13,10,"_wp_trash_meta_status","publish"),
(14,10,"_wp_trash_meta_time","1497030151"),
(15,11,"_wp_trash_meta_status","publish"),
(16,11,"_wp_trash_meta_time","1497030630");
