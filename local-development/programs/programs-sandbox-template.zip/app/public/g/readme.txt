Globals naming convention:

/g/[version]/[filedirectory]/[file][?v=version]

examples:
/g/2/c/g.css?v=2.0.1
/g/2.1/c/g.css?v=2.1.1

Filedirectory descriptions:
c = css
f = fonts
h = html
i = images
j = css