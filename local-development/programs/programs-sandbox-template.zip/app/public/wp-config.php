<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', 'root' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '4BYPTA4VzoLAa53HshLFKRNuRA0H/T2ZIkGM6lXULGci3Wq5Mq2S2T89gdd7ApnvfIguchR7m2z0L1KGxIFCUw==');
define('SECURE_AUTH_KEY',  'uBXGIKeP3yAkf8vruZvBDpOyqBlYmga1kt+hwXc0DBUWpDkP6muaDyoqz9dXWtceAYdmXVMou46GYz1Bg2Hyaw==');
define('LOGGED_IN_KEY',    'xiG9CA2l/2ddbaG3Cg1fDCG6PKCUQX/P5UjIl2btbY76qa7NLgtv9mAqtWBRwhi+Jqt5GTmp7zoYUdIxmAJQ9g==');
define('NONCE_KEY',        'hOKO5bs0d14Xk4ZqYQ1jCkNNqYPboJt5SPJaWtcacFSpw3+9gIvTP2A0BrnMqJd/+QCc9POSwZ2M0LYch+fSwA==');
define('AUTH_SALT',        'WvHxxpC20uaATf9fungOvcIuMqZVTl6CylabLkbnTlqXhjRsXAVp/nd2orw2hlFmRNHteZfSKjVAeFJja+WN3A==');
define('SECURE_AUTH_SALT', '2ESV0Bj6mSs/bNgERFuBnjnSm+xkuqKMYLL6jpKs4H+ygloY60hp1gIwbZTSIP9MktUg+yAfdueSiu8aiLtVlg==');
define('LOGGED_IN_SALT',   'C/tzihm8ffwvTCKl8uKNINPl4nXlofWVpE0qHeXAYKvXrd6LWZd8T1gsH29rDTNB3UONrFsxafbIie0yaH7X2w==');
define('NONCE_SALT',       '3COza5ELe1Ys3FgdpdKGu6xlc6hoOfazwXZTKcLhscTs31Sj5/7g7GE9J2iayVQrd0PnNbl5NSFf9zSMPaEIyA==');

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';





/* Inserted by Local by Flywheel. See: http://codex.wordpress.org/Administration_Over_SSL#Using_a_Reverse_Proxy */
if (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https') {
	$_SERVER['HTTPS'] = 'on';
}
/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) )
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
